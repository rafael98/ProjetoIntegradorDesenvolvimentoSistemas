package Controller;

import Model.bean.Setor;
import connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class SetorDAO {
    
    // ação de inserir os dados diretamento no banco de dados
    public void create (Setor s){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("INSERT INTO setor (setor_nome, setor_descricao)VALUES (?,?)");

            stmt.setString(1,s.getSetor_nome());
            stmt.setString(2,s.getSetor_descricao());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com Sucesso ");
                    
            }catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Salvar"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }
    
    }
 
    // ação de alterar os dados diretamento no banco de dados
    public void update (Setor s){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("UPDATE Setor SET setor_nome =?, setor_descricao =? WHERE setor_codigo = ?");

            stmt.setString(1,s.getSetor_nome());
            stmt.setString(2,s.getSetor_descricao());
            stmt.setInt(3,s.getSetor_codigo());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Alterado com Sucesso ");
                    
            }catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Alterar"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }
    
    }
    
    // ação de excluir os dados diretamento no banco de dados
    public void delete (Setor s){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("DELETE FROM Setor WHERE setor_codigo = ?");

            stmt.setInt(1,s.getSetor_codigo());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Removido com Sucesso ");
                    
            }catch (SQLException ex) {
             JOptionPane.showMessageDialog(null, "Erro ao Remover"+ ex);
        }finally{
          ConnectionFactory.closeConnection(con, stmt);
        }
    
    }

    // listagem dos setores cadastrados
    public List<Setor> read(){
   
    Connection con = ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    ResultSet rs = null;
     
       List<Setor> Setores = new ArrayList<>();
        
       try {
           stmt = con.prepareStatement("SELECT * FROM Setor");
           rs = stmt.executeQuery();
           
           while(rs.next()){
                
               Setor Setor = new Setor();              
               Setor.setSetor_codigo(rs.getInt("setor_codigo"));
               Setor.setSetor_nome(rs.getString("setor_nome"));
               Setor.setSetor_descricao(rs.getString("setor_descricao"));
               Setores.add(Setor);
            }
           
       } catch (SQLException ex) {
           Logger.getLogger(SetorDAO.class.getName()).log(Level.SEVERE, null, ex);
       }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
       }
       
       return Setores;
       
    }
 
}
