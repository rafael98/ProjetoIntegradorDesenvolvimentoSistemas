package view;

import Model.bean.ItemSaida;
import Controller.ItemSaidaDAO;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

// classe para cadastro de saida de item:
public class SaidaItem extends javax.swing.JInternalFrame {

    public SaidaItem() {
        initComponents();
        
        DefaultTableModel modelo = (DefaultTableModel)jTableItemSaida.getModel();
        jTableItemSaida.setRowSorter(new TableRowSorter(modelo));
        readTable();
        
        ManipulaInterfaceSaida("Navegar");
    }
    
    // ler e carregar os dados na tabela interface
    public void readTable(){
     DefaultTableModel modelo = (DefaultTableModel)jTableItemSaida.getModel();
     modelo.setNumRows(0);
     ItemSaidaDAO isdao = new ItemSaidaDAO();
     
     for(ItemSaida IS: isdao.read()){
         modelo.addRow(new Object[]{
             IS.getItensSaida_codigo(),
             IS.getItensSaida_nome(),
             IS.getItensSaida_data(),
             IS.getItensSaida_quantidade(),
             IS.getItensSaida_valorVenda(),
         });
     }
    }

    // ação dos botões de novo, alterar, remover
    // bloquear e desbloquear as sequencias de ordens dos botões com as respectivas ação realizadas
    public void ManipulaInterfaceSaida(String modo) {
        switch (modo) {
            case "Navegar":
                itensSaida_codigo.setEnabled(false);
                jButtonNovo.setEnabled(true);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);
                break;

            case "Novo":
                itensSaida_codigo.setEnabled(false);
                jButtonNovo.setEnabled(false);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);

                break;

            case "Alterar":
                itensSaida_codigo.setEnabled(false);
                jButtonNovo.setEnabled(true);
                jButtonSalvar.setEnabled(false);
                jButtonAlterar.setEnabled(true);
                jButtonRemover.setEnabled(true);

                break;

            case "Remover":
                itensSaida_codigo.setEnabled(false);
                jButtonNovo.setEnabled(true);
                jButtonSalvar.setEnabled(false);
                jButtonAlterar.setEnabled(true);
                jButtonRemover.setEnabled(true);
                break;
            default:
                System.out.println("Modo Inválido ");
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabelNome = new javax.swing.JLabel();
        jLabelData = new javax.swing.JLabel();
        itensSaida_valorVenda = new javax.swing.JTextField();
        jLabelQnt = new javax.swing.JLabel();
        jLabelValorV = new javax.swing.JLabel();
        jButtonSalvar = new javax.swing.JButton();
        jButtonAlterar = new javax.swing.JButton();
        jButtonRemover = new javax.swing.JButton();
        itensSaida_nome = new javax.swing.JTextField();
        jButtonNovo = new javax.swing.JButton();
        itensSaida_quantidade = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        itensSaida_codigo = new javax.swing.JTextField();
        itensSaida_data = new javax.swing.JFormattedTextField();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableItemSaida = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Saída de Item");

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados Saída de Item"));

        jLabelNome.setText("Nome");

        jLabelData.setText("Data");

        itensSaida_valorVenda.setBackground(new java.awt.Color(204, 204, 255));

        jLabelQnt.setText("Quantidade");

        jLabelValorV.setText("Valor Venda");

        jButtonSalvar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });

        jButtonAlterar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonAlterar.setText("Alterar");
        jButtonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarActionPerformed(evt);
            }
        });

        jButtonRemover.setBackground(new java.awt.Color(204, 204, 255));
        jButtonRemover.setText("Remover");
        jButtonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoverActionPerformed(evt);
            }
        });

        itensSaida_nome.setBackground(new java.awt.Color(204, 204, 255));

        jButtonNovo.setText("Novo");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });

        itensSaida_quantidade.setBackground(new java.awt.Color(204, 204, 255));
        itensSaida_quantidade.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        jLabel1.setText("Código Item Saída");

        itensSaida_codigo.setBackground(new java.awt.Color(204, 204, 255));

        itensSaida_data.setBackground(new java.awt.Color(204, 204, 255));
        try {
            itensSaida_data.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-##-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButtonNovo)
                .addGap(13, 13, 13)
                .addComponent(jButtonSalvar)
                .addGap(19, 19, 19)
                .addComponent(jButtonAlterar)
                .addGap(18, 18, 18)
                .addComponent(jButtonRemover)
                .addGap(60, 60, 60))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(itensSaida_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(itensSaida_nome)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelNome)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelQnt, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(itensSaida_quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(12, 12, 12)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabelValorV)
                                    .addComponent(itensSaida_valorVenda, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(190, 190, 190)))
                .addGap(128, 128, 128)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(itensSaida_data, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelData))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(itensSaida_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jLabelData))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(itensSaida_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(itensSaida_data, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabelValorV)
                            .addComponent(jLabelQnt))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(itensSaida_valorVenda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(itensSaida_quantidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButtonSalvar)
                            .addComponent(jButtonAlterar)
                            .addComponent(jButtonRemover)
                            .addComponent(jButtonNovo)))))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Itens de Saída Cadastrados:"));

        jTableItemSaida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Item Saida", "Nome", "Data", "Quantidade", "Valor Venda"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableItemSaida.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableItemSaidaMouseClicked(evt);
            }
        });
        jTableItemSaida.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableItemSaidaKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTableItemSaida);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 830, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 352, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jSeparator1)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        setBounds(0, 0, 872, 664);
    }// </editor-fold>//GEN-END:initComponents

    // botao para salvar os dados dos Itens de Saída:
    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        try {
            
            ItemSaida IS = new ItemSaida();
            ItemSaidaDAO DAO = new ItemSaidaDAO();

            IS.setItensSaida_nome(itensSaida_nome.getText());
            IS.setItensSaida_data(itensSaida_data.getText());
            IS.setItensSaida_quantidade(Integer.parseInt(itensSaida_quantidade.getText()));
            IS.setItensSaida_valorVenda(Double.parseDouble(itensSaida_valorVenda.getText()));
            DAO.create(IS);
            readTable();

            {
            }
        } catch (SQLException ex) {
            Logger.getLogger(SaidaItem.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    // botao para alterar os dados dos Itens de Saída:
    private void jButtonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarActionPerformed

        if (jTableItemSaida.getSelectedRow() != -1) {
            
            ItemSaida IS = new ItemSaida();
            ItemSaidaDAO DAO = new ItemSaidaDAO();

            IS.setItensSaida_nome(itensSaida_nome.getText());
            IS.setItensSaida_data(itensSaida_data.getText());
            IS.setItensSaida_quantidade(Integer.parseInt(itensSaida_quantidade.getText()));
            IS.setItensSaida_valorVenda(Double.parseDouble(itensSaida_valorVenda.getText()));
            IS.setItensSaida_codigo((int)jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 0));
            try {
                DAO.update(IS);
            } catch (SQLException ex) {
                Logger.getLogger(SaidaItem.class.getName()).log(Level.SEVERE, null, ex);
            }
            readTable();
           
        } else {
            JOptionPane.showMessageDialog(null, "Selecione um Campo para Alterar.");
        }
        {
        }
        readTable();
    }//GEN-LAST:event_jButtonAlterarActionPerformed

    // botao para remover os dados dos Itens de Saida:
    private void jButtonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoverActionPerformed

        if (jTableItemSaida.getSelectedRow() != -1) {
            
            ItemSaida IS = new ItemSaida();
            ItemSaidaDAO DAO = new ItemSaidaDAO();

            IS.setItensSaida_codigo((int)jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 0));
            try {
                DAO.delete(IS);
            } catch (SQLException ex) {
                Logger.getLogger(SaidaItem.class.getName()).log(Level.SEVERE, null, ex);
            }
            readTable();
            
        } else {
            JOptionPane.showMessageDialog(null, "Selecione um Campo para Excluir.");
        }
        {
        }
        readTable();
    }//GEN-LAST:event_jButtonRemoverActionPerformed

    // botao de limpar os dados de cadastro de itens de saída:
    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed

        itensSaida_nome.setText("");
        itensSaida_data.setText("");
        itensSaida_quantidade.setText("");
        itensSaida_valorVenda.setText("");

        ManipulaInterfaceSaida("Novo");
    }//GEN-LAST:event_jButtonNovoActionPerformed

    // Seleciona com o mouse o campo que deseja fazer as ações: alterar ou remover dados:
    private void jTableItemSaidaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableItemSaidaMouseClicked
      
        if (jTableItemSaida.getSelectedRow()!= -1){
            itensSaida_codigo.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 0).toString());
            itensSaida_nome.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 1).toString());
            itensSaida_data.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 2).toString());
            itensSaida_quantidade.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(),3).toString());
            itensSaida_valorVenda.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 4).toString());  
        }
        ManipulaInterfaceSaida("Remover");
        ManipulaInterfaceSaida("Alterar");      
    }//GEN-LAST:event_jTableItemSaidaMouseClicked

    // fazer a alteração dos dados da tabela :
    private void jTableItemSaidaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableItemSaidaKeyReleased
     
        itensSaida_nome.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 1).toString());
        itensSaida_data.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 2).toString());
        itensSaida_quantidade.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(),3).toString());
        itensSaida_valorVenda.setText(jTableItemSaida.getValueAt(jTableItemSaida.getSelectedRow(), 4).toString());
        
    }//GEN-LAST:event_jTableItemSaidaKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField itensSaida_codigo;
    private javax.swing.JFormattedTextField itensSaida_data;
    private javax.swing.JTextField itensSaida_nome;
    private javax.swing.JFormattedTextField itensSaida_quantidade;
    private javax.swing.JTextField itensSaida_valorVenda;
    private javax.swing.JButton jButtonAlterar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonRemover;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelData;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelQnt;
    private javax.swing.JLabel jLabelValorV;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableItemSaida;
    // End of variables declaration//GEN-END:variables

    private void setText(String toString) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
