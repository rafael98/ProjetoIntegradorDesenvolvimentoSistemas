package Model.bean;

public class ItemEntrada extends Fornecedor {
    // atributos da classe ItemEntrada:
    private int itensEnt_codigo;
    private String itensEnt_nome;
    private String itensEnt_data;
    private int itensEnt_quantidade;
    private double itensEnt_valorCusto;
    private Fornecedor fornecedor;

    
    // construtores:
    public ItemEntrada() {
    }

    public ItemEntrada(int itensEnt_codigo, String itensEnt_nome, String itensEnt_data, 
                       int itensEnt_quantidade, double itensEnt_valorCusto, String forn_nome, Fornecedor fornecedor) {
        
        this.itensEnt_codigo = itensEnt_codigo;
        this.itensEnt_nome = itensEnt_nome;
        this.itensEnt_data = itensEnt_data;
        this.itensEnt_quantidade = itensEnt_quantidade;
        this.itensEnt_valorCusto = itensEnt_valorCusto;
        this.fornecedor = fornecedor;

    }
    
    // métodos set e get:
    public int getItensEnt_codigo() {
        return itensEnt_codigo;
    }

    public void setItensEnt_codigo(int itensEnt_codigo) {
        this.itensEnt_codigo = itensEnt_codigo;
    }
 
    
    public String getItensEnt_nome() {
        return itensEnt_nome;
    }

    public void setItensEnt_nome(String itensEnt_nome) {
        this.itensEnt_nome = itensEnt_nome;
    }

    public String getItensEnt_data() {
        return itensEnt_data;
    }

    public void setItensEnt_data(String itensEnt_data) {
        this.itensEnt_data = itensEnt_data;
    }

    public int getItensEnt_quantidade() {
        return itensEnt_quantidade;
    }

    public void setItensEnt_quantidade(int itensEnt_quantidade) {
        this.itensEnt_quantidade = itensEnt_quantidade;
    }

    public double getItensEnt_valorCusto() {
        return itensEnt_valorCusto;
    }

    public void setItensEnt_valorCusto(double itensEnt_valorCusto) {
        this.itensEnt_valorCusto = itensEnt_valorCusto;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }
 
}
