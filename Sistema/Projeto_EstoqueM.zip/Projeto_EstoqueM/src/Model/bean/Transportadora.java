package Model.bean;

public class Transportadora {
    // atributos da classe Transportadora:
    private int transp_codigo;
    private String transp_nome;
    private int transp_cep;
    private String transp_rua;
    private int transp_numero;
    private String transp_cidade;
    private int transp_telefone;

    // construtores:
    public Transportadora() {
    }

    public Transportadora(int transp_codigo, String transp_nome, int transp_cep, 
                         String transp_rua, int transp_numero, String transp_cidade,int transp_telefone) {
        
        this.transp_codigo = transp_codigo;
        this.transp_nome = transp_nome;
        this.transp_cep = transp_cep;
        this.transp_rua = transp_rua;
        this.transp_numero = transp_numero;
        this.transp_cidade = transp_cidade;
        this.transp_telefone = transp_telefone;
    }

    // métodos set e get:
    
    public int getTransp_codigo() {
        return transp_codigo;
    }

    public void setTransp_codigo(int transp_codigo) {
        this.transp_codigo = transp_codigo;
    }

    
    public String getTransp_nome() {
        return transp_nome;
    }

    public void setTransp_nome(String transp_nome) {
        this.transp_nome = transp_nome;
    }

    public int getTransp_cep() {
        return transp_cep;
    }

    public void setTransp_cep(int transp_cep) {
        this.transp_cep = transp_cep;
    }

    public String getTransp_rua() {
        return transp_rua;
    }

    public void setTransp_rua(String transp_rua) {
        this.transp_rua = transp_rua;
    }
    
    public int getTransp_numero() {
        return transp_numero;
    }

    public void setTransp_numero(int transp_numero) {
        this.transp_numero = transp_numero;
    }

    public String getTransp_cidade() {
        return transp_cidade;
    }

    public void setTransp_cidade(String transp_cidade) {
        this.transp_cidade = transp_cidade;
    }

    public int getTransp_telefone() {
        return transp_telefone;
    }

    public void setTransp_telefone(int transp_telefone) {
        this.transp_telefone = transp_telefone;
    }    
    
}
