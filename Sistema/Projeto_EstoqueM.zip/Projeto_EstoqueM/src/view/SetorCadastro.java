package view;
import Model.bean.Setor;
import Controller.SetorDAO;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

//classe de cadastro de setor:
public class SetorCadastro extends javax.swing.JInternalFrame {

    public SetorCadastro() {        
        
        initComponents();
        DefaultTableModel modelo = (DefaultTableModel)jTableDadosSetorCad.getModel();
        jTableDadosSetorCad.setRowSorter(new TableRowSorter(modelo));
        readTable();
   
        ManipulaInterfaceSetor("Navegar");
      
    }
    
     // ler e carregar os dados na tabela interface
     public void readTable(){
     DefaultTableModel modelo = (DefaultTableModel)jTableDadosSetorCad.getModel();
     modelo.setNumRows(0);
     SetorDAO sdao = new SetorDAO();
     
     for(Setor setor: sdao.read()){
         modelo.addRow(new Object[]{
             setor.getSetor_codigo(),
             setor.getSetor_nome(),
             setor.getSetor_descricao(),
         });
     }
    }
   
     // ação dos botões de novo, alterar, remover
     // bloquear e desbloquear as sequencias de ordens dos botões com as respectivas ação realizadas
    public void ManipulaInterfaceSetor (String modo){
             switch (modo){
               case "Navegar":
                setor_codigo.setEnabled(false);
                jButtonNovo.setEnabled(true);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);
                break;
            
                case "Novo":
                setor_codigo.setEnabled(false);
                jButtonNovo.setEnabled(false);
                jButtonSalvar.setEnabled(true);
                jButtonAlterar.setEnabled(false);
                jButtonRemover.setEnabled(false);
                  
              break; 
              
           case "Alterar":
              setor_codigo.setEnabled(false);
              jButtonNovo.setEnabled(true);
              jButtonSalvar.setEnabled(false);
              jButtonAlterar.setEnabled(true);
              jButtonRemover.setEnabled(true);       
               
               break;
                   
           case "Remover":
              setor_codigo.setEnabled(false); 
              jButtonNovo.setEnabled(true);
              jButtonSalvar.setEnabled(false);
              jButtonAlterar.setEnabled(true);
              jButtonRemover.setEnabled(true);
               break;
           default: System.out.println("Modo Inválido ");        
           }

    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelDadosSetor = new javax.swing.JPanel();
        setor_nome = new javax.swing.JTextField();
        jLabelNomeSetor = new javax.swing.JLabel();
        setor_descricao = new javax.swing.JTextField();
        jLabelDesc = new javax.swing.JLabel();
        jButtonSalvar = new javax.swing.JButton();
        jButtonAlterar = new javax.swing.JButton();
        jButtonRemover = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        setor_codigo = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableDadosSetorCad = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Cadastro Setor");
        setDoubleBuffered(true);

        jPanelDadosSetor.setBackground(new java.awt.Color(153, 153, 255));
        jPanelDadosSetor.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Setor"));

        setor_nome.setBackground(new java.awt.Color(204, 204, 255));

        jLabelNomeSetor.setText("Nome");

        setor_descricao.setBackground(new java.awt.Color(204, 204, 255));

        jLabelDesc.setText("Descrição");

        jButtonSalvar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });

        jButtonAlterar.setBackground(new java.awt.Color(204, 204, 255));
        jButtonAlterar.setText("Alterar");
        jButtonAlterar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarActionPerformed(evt);
            }
        });

        jButtonRemover.setBackground(new java.awt.Color(204, 204, 255));
        jButtonRemover.setText("Remover");
        jButtonRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoverActionPerformed(evt);
            }
        });

        jButtonNovo.setText("Novo");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });

        jLabel1.setText("Código Setor");

        setor_codigo.setBackground(new java.awt.Color(204, 204, 255));

        javax.swing.GroupLayout jPanelDadosSetorLayout = new javax.swing.GroupLayout(jPanelDadosSetor);
        jPanelDadosSetor.setLayout(jPanelDadosSetorLayout);
        jPanelDadosSetorLayout.setHorizontalGroup(
            jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelDadosSetorLayout.createSequentialGroup()
                .addContainerGap(471, Short.MAX_VALUE)
                .addComponent(jButtonNovo)
                .addGap(18, 18, 18)
                .addComponent(jButtonSalvar)
                .addGap(18, 18, 18)
                .addComponent(jButtonAlterar)
                .addGap(18, 18, 18)
                .addComponent(jButtonRemover)
                .addGap(35, 35, 35))
            .addGroup(jPanelDadosSetorLayout.createSequentialGroup()
                .addGroup(jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelDesc)
                    .addComponent(setor_descricao, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 584, Short.MAX_VALUE))
            .addGroup(jPanelDadosSetorLayout.createSequentialGroup()
                .addGroup(jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(setor_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(134, 134, 134)
                .addGroup(jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelNomeSetor)
                    .addComponent(setor_nome, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanelDadosSetorLayout.setVerticalGroup(
            jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDadosSetorLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNomeSetor)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(setor_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(setor_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addComponent(jLabelDesc)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(setor_descricao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanelDadosSetorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonRemover)
                    .addComponent(jButtonAlterar)
                    .addComponent(jButtonSalvar)
                    .addComponent(jButtonNovo))
                .addContainerGap(41, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Setores Cadastrados:"));

        jTableDadosSetorCad.setBackground(new java.awt.Color(240, 240, 240));
        jTableDadosSetorCad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Setor", "Nome", "Descrição"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableDadosSetorCad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableDadosSetorCadMouseClicked(evt);
            }
        });
        jTableDadosSetorCad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableDadosSetorCadKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(jTableDadosSetorCad);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 132, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanelDadosSetor, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.LEADING))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelDadosSetor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setBounds(0, 0, 868, 630);
    }// </editor-fold>//GEN-END:initComponents

    // botao de salvar os dados do setor:
    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
             
        Setor s = new Setor();
        SetorDAO DAO = new SetorDAO();

        s.setSetor_nome(setor_nome.getText());
        s.setSetor_descricao(setor_descricao.getText());
        DAO.create(s);
        readTable();
 
        {
        }
       
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    // botao para alterar dados do Setor:
    private void jButtonAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarActionPerformed
          
        if(jTableDadosSetorCad.getSelectedRow()!= -1){

            Setor s = new Setor();
            SetorDAO DAO = new SetorDAO();

            s.setSetor_nome(setor_nome.getText());
            s.setSetor_descricao(setor_descricao.getText());
            s.setSetor_codigo((int)jTableDadosSetorCad.getValueAt(jTableDadosSetorCad.getSelectedRow(), 0));
            
            DAO.update(s);
            readTable();
            
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Setor para Alterar.");           
        }{
         }
        
    }//GEN-LAST:event_jButtonAlterarActionPerformed

    // botao para remover os Dados do Setor: 
    private void jButtonRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoverActionPerformed
             
        if (jTableDadosSetorCad.getSelectedRow()!= -1) {
            
            Setor s = new Setor();
            SetorDAO DAO = new SetorDAO();

            s.setSetor_codigo((int)jTableDadosSetorCad.getValueAt(jTableDadosSetorCad.getSelectedRow(), 0));
            
            DAO.delete(s);
            readTable();
            
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Setor para Excluir.");       
        } {
         }
        
    }//GEN-LAST:event_jButtonRemoverActionPerformed

    // botao de limpar os dados de cadastro de setor:
    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed

        setor_nome.setText("");
        setor_descricao.setText("");
                
       ManipulaInterfaceSetor("Novo");        
    }//GEN-LAST:event_jButtonNovoActionPerformed

    // Seleciona com o mouse o campo que deseja fazer as ações: alterar ou remover dados:
    private void jTableDadosSetorCadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableDadosSetorCadMouseClicked
       
        if (jTableDadosSetorCad.getSelectedRow()!= -1){
            setor_codigo.setText(jTableDadosSetorCad.getValueAt(jTableDadosSetorCad.getSelectedRow(), 0).toString());
            setor_nome.setText(jTableDadosSetorCad.getValueAt(jTableDadosSetorCad.getSelectedRow(), 1).toString());
            setor_descricao.setText(jTableDadosSetorCad.getValueAt(jTableDadosSetorCad.getSelectedRow(), 2).toString());
 
        } 
        ManipulaInterfaceSetor("Remover"); 
        ManipulaInterfaceSetor("Alterar"); 
    }//GEN-LAST:event_jTableDadosSetorCadMouseClicked

    // fazer a alteração dos dados da tabela :
    private void jTableDadosSetorCadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableDadosSetorCadKeyReleased

        setor_nome.setText(jTableDadosSetorCad.getValueAt(jTableDadosSetorCad.getSelectedRow(), 1).toString());
        setor_descricao.setText(jTableDadosSetorCad.getValueAt(jTableDadosSetorCad.getSelectedRow(), 2).toString());

    }//GEN-LAST:event_jTableDadosSetorCadKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAlterar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonRemover;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelDesc;
    private javax.swing.JLabel jLabelNomeSetor;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanelDadosSetor;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableDadosSetorCad;
    private javax.swing.JTextField setor_codigo;
    private javax.swing.JTextField setor_descricao;
    private javax.swing.JTextField setor_nome;
    // End of variables declaration//GEN-END:variables
}
