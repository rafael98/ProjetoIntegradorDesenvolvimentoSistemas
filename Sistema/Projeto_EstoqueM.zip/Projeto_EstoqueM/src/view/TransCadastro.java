package view;

import Model.bean.Transportadora;
import Controller.TransportadoraDao;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

//classe para cadastro da transportadora:
public class TransCadastro extends javax.swing.JInternalFrame {

    public TransCadastro() {
        initComponents();
        
        DefaultTableModel modelo = (DefaultTableModel)jTableDadosTransCad.getModel();
        jTableDadosTransCad.setRowSorter(new TableRowSorter(modelo));
        readTable();
        
        ManipulaInterfaceTransp("Navegar");  
        
    }
    
    // ler e carregar os dados na tabela interface
    public void readTable(){
     DefaultTableModel modelo = (DefaultTableModel)jTableDadosTransCad.getModel();
     modelo.setNumRows(0);
     TransportadoraDao tdao = new TransportadoraDao();
     
     for(Transportadora t: tdao.read()){
         modelo.addRow(new Object[]{
             t.getTransp_codigo(),
             t.getTransp_nome(),
             t.getTransp_cep(),
             t.getTransp_rua(),
             t.getTransp_numero(),
             t.getTransp_cidade(),
             t.getTransp_telefone(),
         });
     }
    }
    
    // ação dos botões de novo, alterar, remover
    // bloquear e desbloquear as sequencias de ordens dos botões com as respectivas ação realizadas
    public void ManipulaInterfaceTransp (String modo){
             switch (modo){
               case "Navegar":
                transp_codigo.setEnabled(false);
                jButtonNovo.setEnabled(true);
                jButtonSalvarTrans.setEnabled(true);
                jButtonAlterarTrans.setEnabled(false);
                jButtonRemoverTrans.setEnabled(false);
                break;
            
                case "Novo":
                transp_codigo.setEnabled(false);    
                jButtonNovo.setEnabled(false);
                jButtonSalvarTrans.setEnabled(true);
                jButtonAlterarTrans.setEnabled(false);
                jButtonRemoverTrans.setEnabled(false);
                  
              break; 
              
           case "Alterar":
              transp_codigo.setEnabled(false); 
              jButtonNovo.setEnabled(true);
              jButtonSalvarTrans.setEnabled(false);
              jButtonAlterarTrans.setEnabled(true);
              jButtonRemoverTrans.setEnabled(true);       
               
               break;
                   
           case "Remover":
              transp_codigo.setEnabled(false); 
              jButtonNovo.setEnabled(true);
              jButtonSalvarTrans.setEnabled(false);
              jButtonAlterarTrans.setEnabled(true);
              jButtonRemoverTrans.setEnabled(true);
               break;
           default: System.out.println("Modo Inválido ");        
           }    
    
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelDadosTrans = new javax.swing.JPanel();
        transp_nome = new javax.swing.JTextField();
        jLabelNome = new javax.swing.JLabel();
        transp_rua = new javax.swing.JTextField();
        jLabelRua = new javax.swing.JLabel();
        transp_cep = new javax.swing.JFormattedTextField();
        jLabelCep = new javax.swing.JLabel();
        transp_cidade = new javax.swing.JTextField();
        jLabelCidade = new javax.swing.JLabel();
        transp_telefone = new javax.swing.JFormattedTextField();
        jLabelTel1 = new javax.swing.JLabel();
        jButtonSalvarTrans = new javax.swing.JButton();
        jButtonAlterarTrans = new javax.swing.JButton();
        jButtonRemoverTrans = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();
        jLabelT_Num = new javax.swing.JLabel();
        transp_numero = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        transp_codigo = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableDadosTransCad = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Cadastro Transpotadora");

        jPanelDadosTrans.setBackground(new java.awt.Color(153, 153, 255));
        jPanelDadosTrans.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Transpostador"));

        transp_nome.setBackground(new java.awt.Color(204, 204, 255));

        jLabelNome.setText("Nome");

        transp_rua.setBackground(new java.awt.Color(204, 204, 255));

        jLabelRua.setText("Rua");

        transp_cep.setBackground(new java.awt.Color(204, 204, 255));
        try {
            transp_cep.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("########")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabelCep.setText("CEP");

        transp_cidade.setBackground(new java.awt.Color(204, 204, 255));

        jLabelCidade.setText("Cidade");

        transp_telefone.setBackground(new java.awt.Color(204, 204, 255));
        try {
            transp_telefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("########")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabelTel1.setText("Telefone");

        jButtonSalvarTrans.setBackground(new java.awt.Color(204, 204, 255));
        jButtonSalvarTrans.setText("Salvar");
        jButtonSalvarTrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarTransActionPerformed(evt);
            }
        });

        jButtonAlterarTrans.setBackground(new java.awt.Color(204, 204, 255));
        jButtonAlterarTrans.setText("Alterar");
        jButtonAlterarTrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarTransActionPerformed(evt);
            }
        });

        jButtonRemoverTrans.setBackground(new java.awt.Color(204, 204, 255));
        jButtonRemoverTrans.setText("Remover");
        jButtonRemoverTrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemoverTransActionPerformed(evt);
            }
        });

        jButtonNovo.setText("Novo");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });

        jLabelT_Num.setText("Numero");

        transp_numero.setBackground(new java.awt.Color(204, 204, 255));
        try {
            transp_numero.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel1.setText("Código Transportador");

        transp_codigo.setBackground(new java.awt.Color(204, 204, 255));

        javax.swing.GroupLayout jPanelDadosTransLayout = new javax.swing.GroupLayout(jPanelDadosTrans);
        jPanelDadosTrans.setLayout(jPanelDadosTransLayout);
        jPanelDadosTransLayout.setHorizontalGroup(
            jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelDadosTransLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButtonNovo)
                .addGap(18, 18, 18)
                .addComponent(jButtonSalvarTrans)
                .addGap(18, 18, 18)
                .addComponent(jButtonAlterarTrans)
                .addGap(18, 18, 18)
                .addComponent(jButtonRemoverTrans)
                .addGap(17, 17, 17))
            .addGroup(jPanelDadosTransLayout.createSequentialGroup()
                .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelCep)
                    .addComponent(transp_cep, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(transp_telefone, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelTel1)
                    .addComponent(jLabel1)
                    .addComponent(transp_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanelDadosTransLayout.createSequentialGroup()
                        .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelRua)
                            .addComponent(transp_rua, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(44, 44, 44)
                        .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabelT_Num, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(transp_numero))
                        .addGap(97, 97, 97)
                        .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelCidade)
                            .addComponent(transp_cidade, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(149, Short.MAX_VALUE))
                    .addGroup(jPanelDadosTransLayout.createSequentialGroup()
                        .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(transp_nome, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabelNome))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanelDadosTransLayout.setVerticalGroup(
            jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelDadosTransLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNome)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(transp_nome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(transp_codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelRua)
                    .addComponent(jLabelCep)
                    .addComponent(jLabelCidade)
                    .addComponent(jLabelT_Num))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(transp_rua, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(transp_cep, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(transp_cidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(transp_numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addComponent(jLabelTel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(transp_telefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanelDadosTransLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonSalvarTrans)
                    .addComponent(jButtonAlterarTrans)
                    .addComponent(jButtonRemoverTrans)
                    .addComponent(jButtonNovo))
                .addGap(27, 27, 27))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Dados do Transportador Cadastrados:"));

        jTableDadosTransCad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Código Transportador", "Nome", "CEP", "Rua", "Numero", "Cidade", "Telefone"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableDadosTransCad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableDadosTransCadMouseClicked(evt);
            }
        });
        jTableDadosTransCad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTableDadosTransCadKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTableDadosTransCad);
        if (jTableDadosTransCad.getColumnModel().getColumnCount() > 0) {
            jTableDadosTransCad.getColumnModel().getColumn(0).setResizable(false);
            jTableDadosTransCad.getColumnModel().getColumn(1).setResizable(false);
            jTableDadosTransCad.getColumnModel().getColumn(2).setResizable(false);
            jTableDadosTransCad.getColumnModel().getColumn(3).setResizable(false);
            jTableDadosTransCad.getColumnModel().getColumn(4).setResizable(false);
        }

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(114, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanelDadosTrans, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanelDadosTrans, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setBounds(0, 0, 871, 630);
    }// </editor-fold>//GEN-END:initComponents

    // botao para salvar os dados da transportadora:
    private void jButtonSalvarTransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarTransActionPerformed
        
        Transportadora t = new Transportadora();
        TransportadoraDao dao = new TransportadoraDao();
        
        t.setTransp_nome(transp_nome.getText());
        t.setTransp_cep(Integer.parseInt(transp_cep.getText()));
        t.setTransp_rua(transp_rua.getText());
        t.setTransp_numero(Integer.parseInt(transp_numero.getText()));
        t.setTransp_cidade(transp_cidade.getText());
        t.setTransp_telefone(Integer.parseInt(transp_telefone.getText()));
        dao.create(t);
        readTable();
        {
      
        }
    }//GEN-LAST:event_jButtonSalvarTransActionPerformed

    // Seleciona o mouse para escolher o campo para alterar ou remover dados:
    private void jTableDadosTransCadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableDadosTransCadMouseClicked
             
        if (jTableDadosTransCad.getSelectedRow()!= -1){
            
            transp_codigo.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 0).toString());
            transp_nome.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 1).toString());
            transp_cep.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 2).toString());
            transp_rua.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 3).toString());
            transp_numero.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 4).toString());
            transp_cidade.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 5).toString());
            transp_telefone.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 6).toString()); 
          
        }   
        ManipulaInterfaceTransp("Remover");
        ManipulaInterfaceTransp("Alterar");
    }//GEN-LAST:event_jTableDadosTransCadMouseClicked

    // botao para alterar dados do transportador:
    private void jButtonAlterarTransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarTransActionPerformed
            
        if(jTableDadosTransCad.getSelectedRow()!= -1){
 
        Transportadora t = new Transportadora();
        TransportadoraDao dao = new TransportadoraDao();
        
        t.setTransp_nome(transp_nome.getText());
        t.setTransp_cep(Integer.parseInt(transp_cep.getText()));
        t.setTransp_rua(transp_rua.getText());
        t.setTransp_numero(Integer.parseInt(transp_numero.getText()));
        t.setTransp_cidade(transp_cidade.getText());
        t.setTransp_telefone(Integer.parseInt(transp_telefone.getText()));
        t.setTransp_codigo((int)jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 0));
        dao.update(t);
         
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Transportador para Alterar.");           
        }{
         } 
    }//GEN-LAST:event_jButtonAlterarTransActionPerformed

    // botao para remover os Dados do transportador:
    private void jButtonRemoverTransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemoverTransActionPerformed
        
        if (jTableDadosTransCad.getSelectedRow()!= -1) {
            
        Transportadora t = new Transportadora();
        TransportadoraDao dao = new TransportadoraDao();

        t.setTransp_codigo((int)jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 0));
        dao.delete(t);
        readTable();
            
            }else{
            JOptionPane.showMessageDialog(null, "Selecione um Transportador para Excluir.");        
        }{
         }
    }//GEN-LAST:event_jButtonRemoverTransActionPerformed

    // botao de limpar os dados de cadastro do transportador:
    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed

        transp_nome.setText("");
        transp_cep.setText("");
        transp_rua.setText("");
        transp_numero.setText("");
        transp_cidade.setText("");
        transp_telefone.setText(""); 
 
        
        ManipulaInterfaceTransp("Novo");     
    }//GEN-LAST:event_jButtonNovoActionPerformed

    // fazer a alteração dos dados da tabela :
    private void jTableDadosTransCadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTableDadosTransCadKeyReleased
    
        transp_nome.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 1).toString());
        transp_cep.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 2).toString());
        transp_rua.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 3).toString());
        transp_numero.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 4).toString());
        transp_cidade.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 5).toString());
        transp_telefone.setText(jTableDadosTransCad.getValueAt(jTableDadosTransCad.getSelectedRow(), 6).toString());
     
    }//GEN-LAST:event_jTableDadosTransCadKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAlterarTrans;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonRemoverTrans;
    private javax.swing.JButton jButtonSalvarTrans;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelCep;
    private javax.swing.JLabel jLabelCidade;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelRua;
    private javax.swing.JLabel jLabelT_Num;
    private javax.swing.JLabel jLabelTel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanelDadosTrans;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableDadosTransCad;
    private javax.swing.JFormattedTextField transp_cep;
    private javax.swing.JTextField transp_cidade;
    private javax.swing.JTextField transp_codigo;
    private javax.swing.JTextField transp_nome;
    private javax.swing.JFormattedTextField transp_numero;
    private javax.swing.JTextField transp_rua;
    private javax.swing.JFormattedTextField transp_telefone;
    // End of variables declaration//GEN-END:variables

    

}
