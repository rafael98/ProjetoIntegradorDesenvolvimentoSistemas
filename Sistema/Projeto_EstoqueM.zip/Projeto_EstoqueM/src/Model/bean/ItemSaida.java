package Model.bean;

public class ItemSaida {
    // atributos da classe ItemSaida:
    private int itensSaida_codigo;
    private String itensSaida_nome;
    private String itensSaida_data;
    private int itensSaida_quantidade;
    private double itensSaida_valorVenda;
  
    
    // construtores
    public ItemSaida() {
    }

    public ItemSaida( int itensSaida_codigo, String itensSaida_nome, String itensSaida_data, 
                     int itensSaida_quantidade, double itensSaida_valorVenda) {
       
        this.itensSaida_codigo = itensSaida_codigo;
        this.itensSaida_nome = itensSaida_nome;
        this.itensSaida_data = itensSaida_data;
        this.itensSaida_quantidade = itensSaida_quantidade;
        this.itensSaida_valorVenda = itensSaida_valorVenda;
    }

    // métodos set e get:
    
    public int getItensSaida_codigo() {
        return itensSaida_codigo;
    }

    public void setItensSaida_codigo(int itensSaida_codigo) {
        this.itensSaida_codigo = itensSaida_codigo;
    }

    
    public String getItensSaida_nome() {
        return itensSaida_nome;
    }

    public void setItensSaida_nome(String itensSaida_nome) {
        this.itensSaida_nome = itensSaida_nome;
    }

    public String getItensSaida_data() {
        return itensSaida_data;
    }

    public void setItensSaida_data(String itensSaida_data) {
        this.itensSaida_data = itensSaida_data;
    }

    public int getItensSaida_quantidade() {
        return itensSaida_quantidade;
    }

    public void setItensSaida_quantidade(int itensSaida_quantidade) {
        this.itensSaida_quantidade = itensSaida_quantidade;
    }

    public double getItensSaida_valorVenda() {
        return itensSaida_valorVenda;
    }

    public void setItensSaida_valorVenda(double itensSaida_valorVenda) {
        this.itensSaida_valorVenda = itensSaida_valorVenda;
    }

    
}
